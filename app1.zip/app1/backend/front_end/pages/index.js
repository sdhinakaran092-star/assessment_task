import { useEffect, useState } from "react";
import Layout from "../components/Layout";
import NoteCard from "../components/NoteCard";
import NoteEditor from "../components/NoteEditor";
import api, { setAuthToken } from "../lib/api";
import { useAuthStore } from "../stores/authStore";
import { useRouter } from "next/router";

export default function HomePage() {
  const [notes, setNotes] = useState([]);
  const [editing, setEditing] = useState(null);
  const [creating, setCreating] = useState(false);
  const token = useAuthStore(state => state.token);
  const router = useRouter();

  useEffect(() => {
    if (!token) {
      // attempt to read stored token from localStorage via store; if none -> go to signin
      router.push("/signin");
      return;
    }
    setAuthHeader(token);
    fetchNotes();
  }, [token]);

  function setAuthHeader(token) {
    setAuthToken(token);
  }

  async function fetchNotes() {
    try {
      const res = await api.get("/notes");
      setNotes(res.data);
    } catch (err) {
      console.error(err);
      if (err?.response?.status === 401) {
        router.push("/signin");
      }
    }
  }

  async function handleSave(noteData) {
    try {
      if (editing) {
        await api.put(`/notes/${editing.note_id}`, noteData);
        setEditing(null);
      } else {
        await api.post("/notes", noteData);
        setCreating(false);
      }
      fetchNotes();
    } catch (err) {
      console.error(err);
    }
  }

  async function handleDelete(noteId) {
    if (!confirm("Delete this note?")) return;
    try {
      await api.delete(`/notes/${noteId}`);
      fetchNotes();
    } catch (err) {
      console.error(err);
    }
  }

  return (
    <Layout>
      <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
        <h2>Your notes</h2>
        <div>
          <button className="button" onClick={()=>{setCreating(true); setEditing(null);}}>Create note</button>
          <button className="button" style={{marginLeft:8}} onClick={fetchNotes}>Refresh</button>
        </div>
      </div>

      {(creating || editing) && (
        <NoteEditor
          initial={editing}
          onSave={handleSave}
          onCancel={()=>{setCreating(false); setEditing(null)}}
        />
      )}

      <div className="note-grid" style={{marginTop:12}}>
        {notes.length === 0 && <div>No notes yet — create one.</div>}
        {notes.map(n => (
          <NoteCard key={n.note_id} note={n} onEdit={(note)=>setEditing(note)} onDelete={handleDelete} />
        ))}
      </div>
    </Layout>
  );
}

import { useState } from "react";
import api, { setAuthToken } from "../lib/api";
import { useRouter } from "next/router";
import { useAuthStore } from "../stores/authStore";
import Layout from "../components/Layout";

export default function SignInPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();
  const setToken = useAuthStore(state => state.setToken);
  const setUser = useAuthStore(state => state.setUser);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await api.post("/auth/signin", { user_email: email, password });
      const token = res.data.access_token;
      setToken(token);
      setAuth(token);
      router.push("/");
    } catch (err) {
      setError(err?.response?.data?.detail || "Error");
    }
  };

  function setAuth(token) {
    setAuthToken(token);
    // optionally decode token client-side for user info or call /me (not implemented)
  }

  return (
    <Layout>
      <h2>Sign in</h2>
      <form onSubmit={handleSubmit}>
        <input className="input" placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} />
        <input className="input" placeholder="Password" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />
        {error && <div style={{color:"red"}}>{error}</div>}
        <button className="button" type="submit">Sign in</button>
      </form>
    </Layout>
  );
}

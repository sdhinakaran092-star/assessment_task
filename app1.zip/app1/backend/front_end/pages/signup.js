import { useState } from "react";
import api, { setAuthToken } from "../lib/api";
import { useRouter } from "next/router";
import Layout from "../components/Layout";

export default function SignUpPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await api.post("/auth/signup", { user_name: name, user_email: email, password });
      // after signup navigate to signin
      router.push("/signin");
    } catch (err) {
      setError(err?.response?.data?.detail || "Error");
    }
  };

  return (
    <Layout>
      <h2>Sign up</h2>
      <form onSubmit={handleSubmit}>
        <input className="input" placeholder="Name" value={name} onChange={(e)=>setName(e.target.value)} />
        <input className="input" placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} />
        <input className="input" placeholder="Password" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />
        {error && <div style={{color:"red"}}>{error}</div>}
        <button className="button" type="submit">Sign up</button>
      </form>
    </Layout>
  );
}

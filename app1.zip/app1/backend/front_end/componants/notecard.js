export default function NoteCard({ note, onEdit, onDelete }) {
  return (
    <div className="note-card">
      <h3>{note.note_title}</h3>
      <p style={{whiteSpace:"pre-wrap"}}>{note.note_content}</p>
      <div style={{display:"flex", gap:8, marginTop:12}}>
        <button className="button" onClick={() => onEdit(note)}>Edit</button>
        <button style={{background:"#ef4444"}} className="button" onClick={() => onDelete(note.note_id)}>Delete</button>
      </div>
    </div>
  );
}

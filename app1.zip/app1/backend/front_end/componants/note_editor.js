import { useState } from "react";

export default function NoteEditor({ initial, onSave, onCancel }) {
  const [title, setTitle] = useState(initial?.note_title || "");
  const [content, setContent] = useState(initial?.note_content || "");

  return (
    <div style={{marginBottom:18}}>
      <input className="input" value={title} onChange={(e)=>setTitle(e.target.value)} placeholder="Note title" />
      <textarea rows={6} className="input" value={content} onChange={(e)=>setContent(e.target.value)} placeholder="Note content" />
      <div style={{display:"flex", gap:8}}>
        <button className="button" onClick={() => onSave({note_title: title, note_content: content})}>Save</button>
        <button className="button" style={{background:"#6b7280"}} onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}

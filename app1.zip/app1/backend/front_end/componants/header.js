import Link from "next/link";
import { useAuthStore } from "../stores/authStore";
import { useRouter } from "next/router";
import { setAuthToken } from "../lib/api";

export default function Header() {
  const router = useRouter();
  const { token, logout, setToken, setUser } = useAuthStore();

  const handleLogout = () => {
    logout();
    setAuthToken(null);
    router.push("/signin");
  };
  return (
    <div className="header">
      <div style={{fontWeight:700}}>Notes App</div>
      <div>
        {!token ? (
          <>
            <Link href="/signin"><button className="button" style={{marginRight:8}}>Sign in</button></Link>
            <Link href="/signup"><button className="button">Sign up</button></Link>
          </>
        ) : (
          <button className="button" onClick={handleLogout}>Sign out</button>
        )}
      </div>
    </div>
  );
}

from fastapi import FastAPI
from .routes import auth_routes, notes_routes
from .config import settings
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Notes App API")

# CORS (allow frontend)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # in production, restrict this
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_routes.router)
app.include_router(notes_routes.router)

@app.get("/")
async def root():
    return {"msg": "Notes App API running"}

from fastapi import APIRouter, HTTPException, status
from ..schemas import SignupSchema, SigninSchema, TokenResponse, UserOut
from ..deps import users_collection
from ..utils import hash_password, verify_password, create_access_token

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/signup", response_model=UserOut)
async def signup(payload: SignupSchema):
    existing = await users_collection.find_one({"user_email": payload.user_email})
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered")
    hashed = hash_password(payload.password)
    user_doc = {
        "user_name": payload.user_name,
        "user_email": payload.user_email,
        "password_hash": hashed,
        "created_on": None,
        "last_update": None
    }
    # set created_on/last_update automatically
    from datetime import datetime
    now = datetime.utcnow().isoformat()
    user_doc["created_on"] = now
    user_doc["last_update"] = now
    import uuid
    user_doc["user_id"] = str(uuid.uuid4())

    await users_collection.insert_one(user_doc)
    return {"user_id": user_doc["user_id"], "user_name": user_doc["user_name"], "user_email": user_doc["user_email"]}

@router.post("/signin", response_model=TokenResponse)
async def signin(payload: SigninSchema):
    user = await users_collection.find_one({"user_email": payload.user_email})
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    if not verify_password(payload.password, user["password_hash"]):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    token = create_access_token({"user_id": user["user_id"], "user_email": user["user_email"]})
    return {"access_token": token}

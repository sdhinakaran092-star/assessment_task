from fastapi import APIRouter, Depends, HTTPException, status
from typing import List
from ..schemas import NoteCreate, NoteOut
from ..auth import get_current_user
from ..deps import notes_collection
from datetime import datetime
import uuid

router = APIRouter(prefix="/notes", tags=["notes"])

@router.post("/", response_model=NoteOut)
async def create_note(payload: NoteCreate, user=Depends(get_current_user)):
    now = datetime.utcnow().isoformat()
    note = {
        "note_id": str(uuid.uuid4()),
        "note_title": payload.note_title,
        "note_content": payload.note_content,
        "created_on": now,
        "last_update": now,
        "owner_id": user["user_id"]
    }
    await notes_collection.insert_one(note)
    return note

@router.get("/", response_model=List[NoteOut])
async def list_notes(user=Depends(get_current_user)):
    cursor = notes_collection.find({"owner_id": user["user_id"]}).sort("last_update", -1)
    notes = []
    async for n in cursor:
        notes.append(n)
    return notes

@router.get("/{note_id}", response_model=NoteOut)
async def get_note(note_id: str, user=Depends(get_current_user)):
    note = await notes_collection.find_one({"note_id": note_id, "owner_id": user["user_id"]})
    if not note:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Note not found")
    return note

@router.put("/{note_id}", response_model=NoteOut)
async def update_note(note_id: str, payload: NoteCreate, user=Depends(get_current_user)):
    now = datetime.utcnow().isoformat()
    result = await notes_collection.find_one_and_update(
        {"note_id": note_id, "owner_id": user["user_id"]},
        {"$set": {"note_title": payload.note_title, "note_content": payload.note_content, "last_update": now}},
        return_document=True
    )
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Note not found")
    return result

@router.delete("/{note_id}")
async def delete_note(note_id: str, user=Depends(get_current_user)):
    res = await notes_collection.delete_one({"note_id": note_id, "owner_id": user["user_id"]})
    if res.deleted_count == 0:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Note not found")
    return {"detail": "deleted"}



from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field
import uuid

def now_iso():
    return datetime.utcnow().isoformat()

class UserInDB(BaseModel):
    user_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_name: str
    user_email: str
    password_hash: str
    created_on: str = Field(default_factory=now_iso)
    last_update: str = Field(default_factory=now_iso)

class NoteInDB(BaseModel):
    note_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    note_title: str
    note_content: str
    created_on: str = Field(default_factory=now_iso)
    last_update: str = Field(default_factory=now_iso)
    owner_id: str

#!/bin/bash
# wait for mongodb (docker-compose service name: mongo)
echo "Starting backend..."
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
